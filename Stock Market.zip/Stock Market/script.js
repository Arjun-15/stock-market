let setdataKey;
async function fetchStocksData(){
    //implement api call and stock data basedon timeout
    // update chart using fetch api
        try {
            const response = await fetch(`https://stocks3.onrender.com/api/stocks/getstocksdata`);
            const apiData = await response.json();
            console.log('Stock data:', apiData);
            stocksdata = apiData.stocksData[0];
            
            const bookValue = await fetch(`https://stocks3.onrender.com/api/stocks/getstockstatsdata`);
            bookValueData = await bookValue.json();
            console.log('book value data:', bookValueData);
            bookValueData = bookValueData.stocksStatsData[0];
            
            const summary = await fetch(`https://stocks3.onrender.com/api/stocks/getstocksprofiledata`);
            summaryData = await summary.json();
            console.log('Summary data:', summaryData);
            summaryData = summaryData.stocksProfileData[0];
            renderStockList();
            fetchStockData(oneMonth)

        } catch (error) {
            console.error('Error fetching stock data:', error);
        }
}
let stocksdata , bookValueData,summaryData;
fetchStocksData();
async function fetchgraph(data){
    const chartdiv = document.getElementById('myChart');
    const canvas = document.createElement('canvas')
    const ctx = canvas.getContext('2d');
    chartdiv.replaceChildren(canvas);
    chartdiv.style.backgroundColor='lightblue';
const chart = await new Chart(ctx, {
  type: 'line',
  data: {
    labels: data.timeStamp,
    datasets: [{
      label: setdataKey+' Stock Price',
      data: data.value,
      borderColor: 'green',
      backgroundColor: 'blue',
      pointRadius: 0,
      pointHoverRadius: 5
    }]
  },
  options: {
      responsive: true,
      plugins: {
        title: {
          display: false,
          text: 'Chart.js Line Chart'
        },
      },
      setLineDash:[2,2],
      linewidth:2,
      interaction: {
        mode: 'index',
        intersect: false
      },
      scales: {
        x: {
          display: false,
          title: {
            display: false,
            text: 'Month'
          }
        },
        y: {
          display: false,
          title: {
            display: false,
            text: 'Value'
          }
        }
      }
    },
  });
  ctx.strokeStyle = '#ccc';
    ctx.stroke();
    ctx.setLineDash([]);
const tooltip = document.createElement('div');
tooltip.classList.add('chart-tooltip');
tooltip.id='tooltip';
tooltip.style.display='none';
tooltip.style.left='555px';
tooltip.style.top='95px';
tooltip.style.textContent=`${setdataKey}: $${bookValueData[setdataKey].bookValue}`;
}
function fetchStockData(timeRange){
    let ndata;
    ndata = stocksdata[setdataKey]['1mo'];
    if(timeRange == oneMonth)
        ndata = stocksdata[setdataKey]['1mo'];
    else if(timeRange == theeMonth)
        ndata = stocksdata[setdataKey]['3mo'];
    else if(timeRange == oneYear)
        ndata = stocksdata[setdataKey]['1y'];
    else if(timeRange == fiveYear)
        ndata = stocksdata[setdataKey]['5y'];
    fetchgraph(ndata);
}
function renderStockList(){
    //render implement stock list
    const listSection = document.querySelector('.list-section');
    let isFirstValue = true;
    Object.keys(bookValueData).forEach(key => {
        const bookValue = bookValueData[key].bookValue;
        const profit = bookValueData[key].profit;
        // console.log(`${key} - Book Value: ${bookValue}, Profit: ${profit}`);
        const listItem = document.createElement('div');
        const button = document.createElement('button');
        button.classList.add('list');
        button.value = key;
        button.textContent = key;
        const spanValue = document.createElement('span');
        const spanProfit = document.createElement('span');
        spanValue.textContent='$'+bookValue;
        spanValue.style.margin = '0rem 1rem 0rem 1rem';
        spanProfit.textContent=profit+'%';
        spanProfit.style.color = '#90EE90';
        listItem.appendChild(button);
        listItem.appendChild(spanValue);
        listItem.appendChild(spanProfit);
        listItem.addEventListener('click', () => updateDetails(key));
        if(key !== '_id')
        listSection.appendChild(listItem);
        if(isFirstValue){
            isFirstValue = !isFirstValue;
            stockDetails(key)
        }
    });
    
}
function stockDetails(stock){
    //implement display logic
    setdataKey = stock;
    const detailsSection = document.querySelector('.details-section');
    detailsSection.innerHTML = `<div>
    <span id="name">${stock}</span> &nbsp;&nbsp;&nbsp;
     <span id="profit" style="color: green">${bookValueData[stock].profit}%</span> &nbsp;&nbsp;&nbsp;
     <span id="bookValue">$${bookValueData[stock].bookValue}</span></div>
        <!-- Add summary content here (fetch from API) -->
        <p>${summaryData[stock].summary}</p>
    `;
}
const oneMonth = '1month';
const theeMonth = '3month';
const oneYear = '1year';
const fiveYear = '5year';
document.getElementById(oneMonth).addEventListener('click',()=>fetchStockData(oneMonth));
document.getElementById(theeMonth).addEventListener('click',()=>fetchStockData(theeMonth));
document.getElementById(oneYear).addEventListener('click',()=>fetchStockData(oneYear));
document.getElementById(fiveYear).addEventListener('click',()=>fetchStockData(fiveYear));


function updateDetails(key){
    stockDetails(key);
    setdataKey = key;
    fetchStockData();
}



`<div class="chart-container">
                        <canvas id="chartCanvas" width="800" height="400"></canvas>
                        <div class="chart-tooltip" id="tooltip" style="display: none; left: 555px; top: 95px;">AAPL: $156.48</div>
                        <div class="x-axis-label" id="xAxisLabel" style="display: none; font-size: 14px; font-weight: bolder; left: 545px;">1/4/2022</div>
                    </div>
                    <div id="stock-list"><div class="list_i"><button class="list" value="AAPL">AAPL</button><span>$3.953</span><span style="color: #90EE90">0.24%</span></div><div class="list_i"><button class="list" value="MSFT">MSFT</button><span>$26.178</span><span style="color: #90EE90">0.33%</span></div><div class="list_i"><button class="list" value="GOOGL">GOOGL</button><span>$20.507</span><span style="color: #90EE90">0.21%</span></div><div class="list_i"><button class="list" value="AMZN">AMZN</button><span>$15.064</span><span style="color: #90EE90">0.01%</span></div><div class="list_i"><button class="list" value="PYPL">PYPL</button><span>$17.699</span><span style="color: #90EE90">0.10%</span></div><div class="list_i"><button class="list" value="TSLA">TSLA</button><span>$14.129</span><span style="color: red">0.00%</span></div><div class="list_i"><button class="list" value="JPM">JPM</button><span>$98.108</span><span style="color: #90EE90">0.35%</span></div><div class="list_i"><button class="list" value="NVDA">NVDA</button><span>$9.915</span><span style="color: #90EE90">0.19%</span></div><div class="list_i"><button class="list" value="NFLX">NFLX</button><span>$46.654</span><span style="color: red">0.00%</span></div><div class="list_i"><button class="list" value="DIS">DIS</button><span>$53.563</span><span style="color: #90EE90">0.05%</span></div></div>`